'use strict'


var Person = {
	fname : "James",
	lname : "Cameron",
	displayName: function(msg){
		//var message = 'Welcome ' + this.fname + ' , ' + this.lname + ' ' +  msg;
		let message = `Welcome Mr.${this.fname},${this.lname} to ${msg}`;
		console.log (message);
	},
	displayApply:function(msg1,msg2){
		let message = `Welcome Mr.${this.fname},${this.lname} to ${msg1},${msg2}`;
		console.log (message);
	}
	//Person.displayApply.apply(Person,arg);
}

function personApply(){
	var Person = {
		fname : "James",
		lname : "Cameron",
		displayName:function(msg){
			let message = `Welcome Mr.${this.fname},${this.lname} to ${msg[0]},${msg[1]}`;
			console.log (message);
		}	
	};
	Person.displayName.apply(Person,arg);

}

var person = {
	fname : "Steven",
	lname : "Spielberg"
}

Person.displayName.call(Person,'IMAX');
Person.displayName.call(person,['hjk','sadfg']);
//Person.displayApply.apply(person,['hjk','sadfg']);

personApply('IMAX','Cinemas');
